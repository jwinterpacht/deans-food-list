module.exports = {
    production: false,
    development: true,
    node: false
};
